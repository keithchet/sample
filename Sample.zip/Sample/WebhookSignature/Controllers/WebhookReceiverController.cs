﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Security.Cryptography;
using System.Text;
using WebhookSignature.Models;

namespace WebhookSignature.Controllers
{
    [Route("zai-webhook")]
    [ApiController]
    public class WebhookReceiverController : Controller
    {
        private string _secretKey = "dl1u3a30ZvIt4T43Ft2OUdHgdkgMaQ3gPodWM3fyjtnqkegVunrM";
        [HttpPost("batchtransactions-disbursements")]
        public bool Index([FromBody] ZaiBatchTransactionDTO param)
        {
            bool isValid = IsRequestValid(param);
            return isValid;
        }

        private bool IsRequestValid(object param)
        {
            var header = HttpContext.Request.Headers["Webhooks-signature"];
            var stringParam = JsonConvert.SerializeObject(param);
            return !string.IsNullOrEmpty(header) && VerifyWebhook(header, stringParam);
        }

        private bool VerifyWebhook(string header, string requestBody)
        {
            // Step 1: Extract the timestamp and signatures
            Dictionary<string, string> headerValues = ParseHeader(header);
            if (!headerValues.TryGetValue("t", out string timestamp) || !headerValues.TryGetValue("v", out string signature))
            {
                // Handle missing timestamp or signature
                return false;
            }

            // Step 2: Create the signed_payload string
            string signedPayload = $"{timestamp}.{requestBody}";

            // Step 3: Generate the expected signature
            string expectedSignature = GenerateHMACSHA256Signature(signedPayload);

            // Step 4: Compare signatures
            if (ConstantTimeStringCompare(expectedSignature, signature) &&
                IsTimestampValid(long.Parse(timestamp)))
            {
                // Signatures match and timestamp is valid
                return true;
            }

            return false;
        }

        private Dictionary<string, string> ParseHeader(string header)
        {
            Dictionary<string, string> headerValues = new Dictionary<string, string>();
            string[] elements = header.Split(',');
            foreach (string element in elements)
            {
                string[] parts = element.Trim().Split('=');
                if (parts.Length == 2)
                {
                    headerValues[parts[0]] = parts[1];
                }
            }
            return headerValues;
        }

        private string GenerateHMACSHA256Signature(string message)
        {
            using (HMACSHA256 hmac = new HMACSHA256(Encoding.UTF8.GetBytes(_secretKey)))
            {
                byte[] hashBytes = hmac.ComputeHash(Encoding.UTF8.GetBytes(message));
                return Convert.ToBase64String(hashBytes)
                   .Replace("/", "-")
                   .Replace("+", "_")
                   .Replace("=", "");
            }
        }

        private bool ConstantTimeStringCompare(string a, string b)
        {
            if (a.Length != b.Length)
            {
                return false;
            }

            int result = 0;
            for (int i = 0; i < a.Length; i++)
            {
                result |= a[i] ^ b[i];
            }
            return result == 0;
        }

        private bool IsTimestampValid(long timestamp)
        {
            long currentTimestamp = DateTimeOffset.UtcNow.ToUnixTimeSeconds();
            return Math.Abs(currentTimestamp - timestamp) <= 300;
        }
    }
}
