﻿namespace WebhookSignature.Models
{
    public class ZaiBatchTransactionDTO
    {
        public BatchTransactionDTO batch_transactions { get; set; }
    }

    public class BatchTransactionDTO
    {
        public DateTime? created_at { get; set; }
        public DateTime? updated_at { get; set; }
        public Guid id { get; set; }
        public string? account_type { get; set; }
        public string? type { get; set; }
        public string? type_method { get; set; }
        public int? batch_id { get; set; }
        public string? cuscal_payment_transaction_id { get; set; }
        public string? reference { get; set; }
        public string? deposit_reference { get; set; }
        public string? state { get; set; }
        public int? status { get; set; }
        public string? user_id { get; set; }
        public Guid? account_id { get; set; }
        public int? amount { get; set; }
        public string? currency { get; set; }
        public string? debit_credit { get; set; }
        public string? description { get; set; }
        public RelatedDTO? related { get; set; }
        public LinksDTO? links { get; set; }
    }

    public class RelatedDTO
    {
        public AccountToDTO? account_to { get; set; }
        public List<TransactionsDTO>? transactions { get; set; }
    }

    public class AccountToDTO
    {
        public Guid? id { get; set; }
        public string? account_type { get; set; }
        public string? user_id { get; set; }
    }

    public class TransactionsDTO
    {
        public Guid? id { get; set; }
        public DateTime? created_at { get; set; }
        public DateTime? updated_at { get; set; }
        public string? description { get; set; }
        public string? payee_name { get; set; }
        public string? type { get; set; }
        public string? type_method { get; set; }
        public string? state { get; set; }
        public string? user_id { get; set; }
        public string? user_name { get; set; }
        public Guid? account_id { get; set; }
        public string? account_type { get; set; }
        public int amount { get; set; }
        public string? currency { get; set; }
        public string? debit_credit { get; set; }
        public MarketplaceDTO? marketplace { get; set; }
        public RelatedDTO? related { get; set; }
        public PayinDetailsDTO? payin_details { get; set; }
        public LinksDTO? links { get; set; }
    }

    public class MarketplaceDTO
    {
        public string? group_name { get; set; }
        public string? name { get; set; }
        public string? short_name { get; set; }
        public Guid? uuid { get; set; }
    }

    public class PayinDetailsDTO
    {
        public string? debtor_name { get; set; }
        public string? debtor_legal_name { get; set; }
        public string? debtor_bsb { get; set; }
        public string? debtor_account { get; set; }
        public string? clearing_system_transaction_id { get; set; }
        public string? remittance_information { get; set; }
        public string? pay_id { get; set; }
        public string? pay_id_type { get; set; }
        public string? end_to_end_id { get; set; }
        public Guid? npp_payin_internal_id { get; set; }
    }

    public class LinksDTO
    {
        public string? transactions { get; set; }
        public string? wallet_accounts { get; set; }
        public string? bank_accounts { get; set; }
        public string? paypal_accounts { get; set; }
        public string? items { get; set; }
        public string? users { get; set; }
        public string? self { get; set; }
        public string? fees { get; set; }
        public string? card_accounts { get; set; }
        public string? marketplaces { get; set; }
        public string? npp_payin_transaction_detail { get; set; }
    }
}
